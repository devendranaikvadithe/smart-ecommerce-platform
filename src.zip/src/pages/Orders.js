import { useEffect, useState } from "react";
import API from "../api";

export default function Orders() {

const [orders,setOrders]=useState([]);

useEffect(()=>{

API.get("/orders")
.then(res => {
   console.log(res.data);
   setOrders(res.data);
})
.catch(()=>alert("Login required"));

},[]);


return(

<div
style={{
padding:"30px",
background:"#f5f5f5",
minHeight:"100vh"
}}
>

<h1 style={{
marginBottom:"30px"
}}>
📦 My Orders
</h1>


{orders.map(order=>(

<div
key={order._id}

style={{
background:"white",
padding:"25px",
marginBottom:"25px",
borderRadius:"12px",
boxShadow:"0 2px 10px rgba(0,0,0,.1)"
}}
>

<div
style={{
display:"flex",
justifyContent:"space-between"
}}
>

<div>

<h3>
Order ID:
{order._id}
</h3>

<p>
Placed:
{
new Date(
order.createdAt
).toLocaleString()
}
</p>

</div>


<div>

<p>
<b>Name:</b>
{" "}
{order.username}
</p>

<p>
<b>Email:</b>
{" "}
{order.email}
</p>

<p>
<b>Phone:</b>
{" "}
{order.phone}
</p>

</div>

</div>


<hr/>


{order.items?.map((item,i)=>(

<div
key={i}

style={{
display:"flex",
gap:"20px",
alignItems:"center",
marginTop:"20px"
}}
>

<img
src={item.image}
alt=""
style={{
width:"120px",
height:"120px",
borderRadius:"10px",
objectFit:"cover"
}}
/>


<div>

<h3>
{item.title}
</h3>

<p>
Price:
₹{item.price}
</p>

<p>
Quantity:
{item.quantity}
</p>

<p>

Subtotal:
₹{
item.price*
item.quantity
}

</p>

</div>

</div>

))}


<hr/>


<h2
style={{
textAlign:"right"
}}
>

Total:
₹{order.total}

</h2>

</div>

))}

</div>

)

}