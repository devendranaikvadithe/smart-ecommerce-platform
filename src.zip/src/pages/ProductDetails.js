import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import axios from "axios";

import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip
} from "recharts";

export default function ProductDetails() {

  const { id } = useParams();

  const [product,setProduct]=useState(null);

  const [history,setHistory]=useState([]);

  const [targetPrice,setTargetPrice]=useState("");


  const fetchProduct=async()=>{

    try{

      const res=
      await axios.get(
      `https://dummyjson.com/products/${id}`
      );

      setProduct(
      res.data
      );


      const historyRes=
      await axios.get(
      `http://localhost:8000/price-history/${id}`
      );

      setHistory(
      historyRes.data
      );

    }

    catch(err){

      console.log(
      "Fetch Error:",
      err
      );

    }

  };


  useEffect(()=>{

    fetchProduct();

  },[id]);


  const addToCart=async()=>{

    const token=
    localStorage.getItem("token");

    if(!token){

      alert("Login first");

      return;

    }

    await axios.post(

      "http://localhost:8000/cart",

      {
        productId:id.toString(),
        quantity:1
      },

      {
        headers:{
          Authorization:
          `Bearer ${token}`
        }
      }

    );

    alert(
    "Added to cart"
    );

  };



  const saveAlert=async()=>{

    if(
    Number(targetPrice)
    >=
    product.price
    ){

      alert(
      `Enter a value below ₹${product.price}`
      );

      return;

    }


    try{

      const token=
      localStorage.getItem("token");

      if(!token){

        alert("Login first");

        return;

      }

      await axios.post(

      "http://localhost:8000/api/alerts/create",

      {

      productId:
      id.toString(),

      targetPrice:
      Number(targetPrice)

      },

      {

      headers:{

      Authorization:
      `Bearer ${token}`

      }

      }

      );


      alert(
      "Price Alert Created"
      );


      setTargetPrice("");

    }

    catch(err){

      console.log(err);

      alert("Failed");

    }

  };



  if(!product){

    return(
    <p>Loading...</p>
    );

  }



  return(

  <div style={{padding:"20px"}}>

    <img
    src={product.thumbnail}
    width="300"
    alt=""
    />


    <h2>

    {product.title}

    </h2>


    <p>

    {product.description}

    </p>


    <h3>

    ₹{product.price}

    </h3>


    <p>

    Category:
    {product.category}

    </p>



    <button
    onClick={addToCart}
    >

    Add to Cart

    </button>



    <br/><br/>




    <h3>

    🔔 Price Alert

    </h3>


    <input

    type="number"

    placeholder=
    "Notify me at price"

    value={targetPrice}

    onChange={(e)=>

    setTargetPrice(
    e.target.value
    )

    }

    />


    <br/><br/>


    <button
    onClick={saveAlert}
    >

    Set Price Alert

    </button>




    <br/><br/><br/>



    <h3>

    📈 Price History

    </h3>


    <LineChart

    width={600}

    height={300}

    data={history}

    >

    <XAxis
    dataKey="date"
    />

    <YAxis/>

    <Tooltip/>

    <Line

    type="monotone"

    dataKey="price"

    />

    </LineChart>



  </div>

 );

}