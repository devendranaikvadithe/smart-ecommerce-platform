import { useEffect, useState } from "react";
import API from "../api";

export default function Cart(){
  const [cart,setCart]=useState([]);

  const loadCart = async ()=>{
    const res = await API.get("/cart");
    setCart(res.data);
  };

  useEffect(()=>{
    loadCart();
  },[]);

  // ➕ increase
  const increase = async (id, qty)=>{
    await API.put(`/cart/${id}`, { quantity: qty + 1 });
    loadCart();
  };

  // ➖ decrease
  const decrease = async (id, qty)=>{
    if(qty <= 1){
      await API.delete(`/cart/${id}`);
    }else{
      await API.put(`/cart/${id}`, { quantity: qty - 1 });
    }
    loadCart();
  };

  const order = async()=>{
    await API.post("/orders");
    alert("Order placed");
    setCart([]);
  };

  return(
    <div style={{padding:"20px"}}>
      <h2>🛒 Cart</h2>

      {cart.length === 0 && <p>Cart is empty</p>}

      {cart.map((c,i)=>(
        <div key={i} style={{
          display:"flex",
          justifyContent:"space-between",
          marginBottom:"10px",
          background:"#fff",
          padding:"10px",
          borderRadius:"8px"
        }}>
          <div>
            <img src={c.image} width="80" />

            <p>{c.name}</p>
            <p>₹{c.price}</p>
            <p>Qty: {c.quantity}</p>
            <p>Total: ₹{c.price * c.quantity}</p>
          </div>

          <div>
            <button onClick={()=>decrease(c.productId,c.quantity)}>-</button>
            <button onClick={()=>increase(c.productId,c.quantity)}>+</button>
          </div>
        </div>
      ))}

      <button onClick={order}>Place Order</button>
    </div>
  );
}