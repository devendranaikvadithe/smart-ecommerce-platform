import {useState} from "react";
import API from "../api";
import {useNavigate} from "react-router-dom";

export default function Signup(){
  const [form,setForm]=useState({});
  const nav = useNavigate();

  const reg=async()=>{
    await API.post("/register",form);
    nav("/login");
  };

  return(
    <div>
      <input placeholder="name" onChange={e=>setForm({...form,name:e.target.value})}/>
      <input placeholder="email" onChange={e=>setForm({...form,email:e.target.value})}/>
      <input placeholder="phone" onChange={e=>setForm({...form,phone:e.target.value})}/>
      <input type="password" placeholder="password" onChange={e=>setForm({...form,password:e.target.value})}/>
      <button onClick={reg}>Signup</button>
    </div>
  );
}