import { useState } from "react";
import API from "../api";
import { useNavigate } from "react-router-dom";

export default function Login() {
  const [form, setForm] = useState({
    email: "",
    password: ""
  });

  const nav = useNavigate();

  const login = async () => {
    try {
      const res = await API.post("/login", form);

      localStorage.setItem("token", res.data.token);

      alert("Login successful");
      nav("/");
    } catch (err) {
      console.log("LOGIN ERROR:", err);

      if (err.response) {
        alert(err.response.data); // shows "User not found" etc
      } else {
        alert("Server not reachable");
      }
    }
  };

  return (
    <div style={{ padding: "20px" }}>
      <h2>Login</h2>

      <input
        placeholder="email"
        value={form.email}
        onChange={(e) =>
          setForm({ ...form, email: e.target.value })
        }
      />

      <br /><br />

      <input
        type="password"
        placeholder="password"
        value={form.password}
        onChange={(e) =>
          setForm({ ...form, password: e.target.value })
        }
      />

      <br /><br />

      <button onClick={login}>Login</button>
    </div>
  );
}