import React, { useEffect, useState, useCallback } from "react";
import axios from "axios";
import "./Home.css";

export default function Home() {
  const [products, setProducts] = useState([]);
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("");

  // ✅ Fetch products from backend (which calls real API)
  const fetchProducts = useCallback(async () => {
    try {
      let url = "http://localhost:8000/products?";

      if (search) url += `search=${search}&`;
      if (category) url += `category=${category}`;

      const res = await axios.get(url);
      setProducts(res.data);
    } catch (err) {
      console.log("Error:", err);
    }
  }, [search, category]);

  useEffect(() => {
    fetchProducts();
  }, [fetchProducts]);

  // 🛒 Add to cart
  const addToCart = async (product) => {
    try {
      const token = localStorage.getItem("token");

      if (!token) {
        alert("Please login first");
        return;
      }

      await axios.post(
        "http://localhost:8000/cart",
        {
          productId: product.id.toString(), // ✅ IMPORTANT FIX
          quantity: 1
        },
        {
          headers: { Authorization: `Bearer ${token}` }
        }
      );

      alert("Added to cart");
    } catch (err) {
      console.log(err);
      alert("Error adding to cart");
    }
  };

  return (
    <div className="container">
      <h2 className="title">🛍️ Explore Products</h2>

      {/* 🔍 SEARCH + FILTER */}
      <div style={{ display: "flex", gap: "10px", marginBottom: "20px" }}>
        <input
          placeholder="Search products..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />

        {/* ⚠️ DummyJSON categories */}
        <select
          value={category}
          onChange={(e) => setCategory(e.target.value)}
        >
          <option value="">All</option>
          <option value="smartphones">Smartphones</option>
          <option value="laptops">Laptops</option>
          <option value="fragrances">Fragrances</option>
          <option value="skincare">Skincare</option>
          <option value="groceries">Groceries</option>
        </select>

        <button onClick={fetchProducts}>Search</button>
      </div>

      {/* 🛒 PRODUCTS */}
      <div className="grid">
        {products.map((p) => (
          <div
             className="card"
             key={p.id}
             onClick={() => window.location.href = `/product/${p.id}`}
             style={{ cursor: "pointer" }}
            >
            <img src={p.thumbnail} alt={p.title} />
            <h3>{p.title}</h3>
            <p className="price">₹{p.price}</p>
            <p>{p.category}</p>

            <button onClick={() => addToCart(p)}>
              Add to Cart
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}